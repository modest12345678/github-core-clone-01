---
name: obscura
description: >-
  Lightweight, stealthy Rust-native headless browser (h4ckf0r0day/obscura) with V8 JS execution,
  native CSS rendering, screenshots, PDF export, CDP server, and MCP browser tools without Chromium.
  Use when the user asks to browse, fetch, render, screenshot, or scrape web pages using Obscura or
  an agent browser.
---

# Obscura Agent Browser (`obscura` v0.2.6 Stealth + Render)

Obscura (`obscura` / `~\.local\bin\obscura.exe`) is installed on `PATH` and registered as the `obscura` MCP server (`mcp_config.json`).

## 1. MCP Browser Tools (`obscura` MCP Server)

When the `obscura` MCP server is loaded, prefer calling its native MCP tools directly:
- `browser_navigate` — Navigate to a URL (`url`, optional `waitUntil`: `load` / `domcontentloaded` / `networkidle0`)
- `browser_snapshot` — Get current page URL, title, readable text, and interactive element references
- `browser_screenshot` — Capture a PNG image of the current page
- `browser_pdf` — Export the current page as a PDF resource
- `browser_click` — Click an element by snapshot reference or CSS selector
- `browser_fill` / `browser_type` — Fill or type into inputs
- `browser_press_key` / `browser_select_option` — Keyboard events and `<select>` dropdowns
- `browser_evaluate` — Run JavaScript in the page's V8 context and return the result
- `browser_wait_for` — Wait for a CSS selector to appear
- `browser_network_requests` / `browser_console_messages` — Inspect network and console logs
- `browser_close` — Close the page and reset browser state

## 2. CLI Commands (`obscura` on `PATH`)

You can also invoke `obscura` directly from the terminal:

```powershell
# Fetch & render a page (with stealth mode) as markdown, text, html, or links
obscura --stealth fetch https://example.com --dump markdown

# Evaluate JavaScript in V8 on a live page
obscura --stealth fetch https://example.com --eval "document.title"

# Capture a PNG screenshot
obscura --stealth fetch https://example.com --screenshot page.png

# Test against localhost / LAN dev servers (bypass default SSRF block)
obscura --allow-private-network fetch http://127.0.0.1:5000 --dump text

# Scrape multiple URLs in parallel (uses obscura-worker.exe)
obscura --stealth scrape https://example.com https://news.ycombinator.com --format json --quiet

# Start a Chrome DevTools Protocol (CDP) server for Puppeteer / Playwright / agent-browser
obscura --stealth --allow-private-network serve --port 9222
```

## 3. Using with `agent-browser` / Puppeteer / Playwright

- **With `agent-browser`**: Set `AGENT_BROWSER_EXECUTABLE_PATH=~\.local\bin\obscura.exe` and pass `--engine obscura`.
- **With Puppeteer / Playwright**: Start `obscura serve --port 9222 --stealth` and connect to `ws://127.0.0.1:9222/devtools/browser` (or `http://127.0.0.1:9222`).
